# Z score

Tool to find z score

## Installation

pip install zscore
