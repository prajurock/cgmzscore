from .cgmzscore import Calculator
